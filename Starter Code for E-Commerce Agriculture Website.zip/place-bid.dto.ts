import { IsNumber, IsOptional, IsBoolean, Min } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class PlaceBidDto {
  @ApiProperty({ example: 12000 })
  @IsNumber()
  @Min(1)
  amount: number;

  @ApiProperty({ example: 20000, required: false })
  @IsOptional()
  @IsNumber()
  @Min(1)
  maxAmount?: number;

  @ApiProperty({ example: false, required: false })
  @IsOptional()
  @IsBoolean()
  isAuto?: boolean;
}

