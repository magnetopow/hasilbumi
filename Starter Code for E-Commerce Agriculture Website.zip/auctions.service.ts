import { Injectable, NotFoundException, BadRequestException, ForbiddenException } from '@nestjs/common';
import { InjectQueue } from '@nestjs/bull';
import { Queue } from 'bull';
import { PrismaService } from '../common/prisma/prisma.service';
import { CreateAuctionDto } from './dto/create-auction.dto';
import { PlaceBidDto } from './dto/place-bid.dto';
import { AuctionGateway } from './auction.gateway';

@Injectable()
export class AuctionsService {
  constructor(
    private prisma: PrismaService,
    @InjectQueue('auction') private auctionQueue: Queue,
    private auctionGateway: AuctionGateway,
  ) {}

  async createAuction(sellerId: string, createAuctionDto: CreateAuctionDto) {
    const { productId, ...auctionData } = createAuctionDto;

    // Verify product ownership
    const product = await this.prisma.product.findUnique({
      where: { id: productId },
    });

    if (!product) {
      throw new NotFoundException('Produk tidak ditemukan');
    }

    if (product.sellerId !== sellerId) {
      throw new ForbiddenException('Anda tidak memiliki akses untuk membuat lelang produk ini');
    }

    if (!product.isAuctionable) {
      throw new BadRequestException('Produk ini tidak dapat dilelang');
    }

    const auction = await this.prisma.auction.create({
      data: {
        ...auctionData,
        productId,
        sellerId,
        currentPrice: auctionData.startingPrice,
      },
      include: {
        product: true,
        seller: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            username: true,
          },
        },
      },
    });

    // Schedule auction end job
    await this.auctionQueue.add(
      'end-auction',
      { auctionId: auction.id },
      { delay: new Date(auction.endTime).getTime() - Date.now() },
    );

    return auction;
  }

  async placeBid(bidderId: string, auctionId: string, placeBidDto: PlaceBidDto) {
    const auction = await this.prisma.auction.findUnique({
      where: { id: auctionId },
      include: {
        product: true,
        seller: true,
        bids: {
          orderBy: { createdAt: 'desc' },
          take: 1,
        },
      },
    });

    if (!auction) {
      throw new NotFoundException('Lelang tidak ditemukan');
    }

    if (auction.status !== 'ACTIVE') {
      throw new BadRequestException('Lelang tidak aktif');
    }

    if (auction.sellerId === bidderId) {
      throw new BadRequestException('Penjual tidak dapat melakukan bid pada lelang sendiri');
    }

    if (new Date() > auction.endTime) {
      throw new BadRequestException('Lelang telah berakhir');
    }

    const { amount, maxAmount, isAuto } = placeBidDto;

    // Validate bid amount
    if (amount <= auction.currentPrice) {
      throw new BadRequestException(`Bid harus lebih tinggi dari ${auction.currentPrice}`);
    }

    if (amount < auction.currentPrice + auction.bidIncrement) {
      throw new BadRequestException(`Minimum bid increment adalah ${auction.bidIncrement}`);
    }

    // Create bid
    const bid = await this.prisma.bid.create({
      data: {
        auctionId,
        bidderId,
        amount,
        maxAmount,
        isAuto,
      },
      include: {
        bidder: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            username: true,
          },
        },
      },
    });

    // Update auction
    const updatedAuction = await this.prisma.auction.update({
      where: { id: auctionId },
      data: {
        currentPrice: amount,
        totalBids: { increment: 1 },
      },
      include: {
        product: true,
        bids: {
          orderBy: { createdAt: 'desc' },
          take: 5,
          include: {
            bidder: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                username: true,
              },
            },
          },
        },
      },
    });

    // Anti-sniping: extend auction if bid placed in last minutes
    const timeLeft = auction.endTime.getTime() - Date.now();
    if (auction.isAutoExtend && timeLeft < auction.extendMinutes * 60 * 1000) {
      const newEndTime = new Date(Date.now() + auction.extendMinutes * 60 * 1000);
      
      await this.prisma.auction.update({
        where: { id: auctionId },
        data: { endTime: newEndTime },
      });

      updatedAuction.endTime = newEndTime;
    }

    // Emit real-time update
    this.auctionGateway.emitBidUpdate(auctionId, {
      auction: updatedAuction,
      newBid: bid,
    });

    // Process auto-bidding for other bidders
    await this.processAutoBidding(auctionId, amount, bidderId);

    return {
      bid,
      auction: updatedAuction,
      message: 'Bid berhasil ditempatkan',
    };
  }

  async getAuctions(page = 1, limit = 10, status?: string) {
    const skip = (page - 1) * limit;
    const where: any = {};

    if (status) {
      where.status = status;
    }

    const [auctions, total] = await Promise.all([
      this.prisma.auction.findMany({
        where,
        skip,
        take: limit,
        include: {
          product: true,
          seller: {
            select: {
              id: true,
              firstName: true,
              lastName: true,
              username: true,
            },
          },
          _count: {
            select: {
              bids: true,
            },
          },
        },
        orderBy: {
          createdAt: 'desc',
        },
      }),
      this.prisma.auction.count({ where }),
    ]);

    return {
      auctions,
      pagination: {
        page,
        limit,
        total,
        totalPages: Math.ceil(total / limit),
      },
    };
  }

  async getAuctionById(id: string) {
    const auction = await this.prisma.auction.findUnique({
      where: { id },
      include: {
        product: true,
        seller: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            username: true,
            sellerProfile: {
              select: {
                businessName: true,
                rating: true,
              },
            },
          },
        },
        winner: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            username: true,
          },
        },
        bids: {
          orderBy: { createdAt: 'desc' },
          take: 20,
          include: {
            bidder: {
              select: {
                id: true,
                firstName: true,
                lastName: true,
                username: true,
              },
            },
          },
        },
      },
    });

    if (!auction) {
      throw new NotFoundException('Lelang tidak ditemukan');
    }

    return auction;
  }

  async endAuction(auctionId: string) {
    const auction = await this.prisma.auction.findUnique({
      where: { id: auctionId },
      include: {
        bids: {
          orderBy: { amount: 'desc' },
          take: 1,
          include: {
            bidder: true,
          },
        },
      },
    });

    if (!auction) {
      throw new NotFoundException('Lelang tidak ditemukan');
    }

    const highestBid = auction.bids[0];
    const winnerId = highestBid?.bidderId || null;

    const updatedAuction = await this.prisma.auction.update({
      where: { id: auctionId },
      data: {
        status: 'ENDED',
        winnerId,
      },
      include: {
        product: true,
        winner: {
          select: {
            id: true,
            firstName: true,
            lastName: true,
            username: true,
          },
        },
      },
    });

    // Emit auction end event
    this.auctionGateway.emitAuctionEnd(auctionId, updatedAuction);

    return updatedAuction;
  }

  private async processAutoBidding(auctionId: string, currentHighestBid: number, excludeBidderId: string) {
    const autoBids = await this.prisma.bid.findMany({
      where: {
        auctionId,
        isAuto: true,
        maxAmount: { gt: currentHighestBid },
        bidderId: { not: excludeBidderId },
      },
      include: {
        bidder: true,
      },
      orderBy: {
        maxAmount: 'desc',
      },
    });

    for (const autoBid of autoBids) {
      const auction = await this.prisma.auction.findUnique({
        where: { id: auctionId },
      });

      if (!auction || auction.status !== 'ACTIVE') break;

      const nextBidAmount = Math.min(
        autoBid.maxAmount,
        auction.currentPrice + auction.bidIncrement,
      );

      if (nextBidAmount > auction.currentPrice) {
        await this.placeBid(autoBid.bidderId, auctionId, {
          amount: nextBidAmount,
          maxAmount: autoBid.maxAmount,
          isAuto: true,
        });
      }
    }
  }
}

