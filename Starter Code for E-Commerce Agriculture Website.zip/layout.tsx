import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { Providers } from '@/components/providers';
import { Toaster } from 'react-hot-toast';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
  title: 'AgriCommerce - Platform E-commerce Bahan Pertanian',
  description: 'Platform e-commerce modern untuk perdagangan bahan pertanian dengan fitur lelang real-time, sistem escrow, dan chat real-time.',
  keywords: 'pertanian, e-commerce, lelang, bahan pertanian, organik',
  authors: [{ name: 'AgriCommerce Team' }],
  creator: 'AgriCommerce',
  publisher: 'AgriCommerce',
  formatDetection: {
    email: false,
    address: false,
    telephone: false,
  },
  manifest: '/manifest.json',
  themeColor: '#22c55e',
  viewport: {
    width: 'device-width',
    initialScale: 1,
    maximumScale: 1,
  },
  icons: {
    icon: '/favicon.ico',
    shortcut: '/favicon-16x16.png',
    apple: '/apple-touch-icon.png',
  },
  openGraph: {
    type: 'website',
    locale: 'id_ID',
    url: 'https://agricommerce.com',
    title: 'AgriCommerce - Platform E-commerce Bahan Pertanian',
    description: 'Platform e-commerce modern untuk perdagangan bahan pertanian dengan fitur lelang real-time, sistem escrow, dan chat real-time.',
    siteName: 'AgriCommerce',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'AgriCommerce - Platform E-commerce Bahan Pertanian',
    description: 'Platform e-commerce modern untuk perdagangan bahan pertanian dengan fitur lelang real-time, sistem escrow, dan chat real-time.',
    creator: '@agricommerce',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="id" className="h-full">
      <body className={`${inter.className} h-full`}>
        <Providers>
          {children}
          <Toaster
            position="top-right"
            toastOptions={{
              duration: 4000,
              style: {
                background: '#363636',
                color: '#fff',
              },
              success: {
                duration: 3000,
                iconTheme: {
                  primary: '#22c55e',
                  secondary: '#fff',
                },
              },
              error: {
                duration: 5000,
                iconTheme: {
                  primary: '#ef4444',
                  secondary: '#fff',
                },
              },
            }}
          />
        </Providers>
      </body>
    </html>
  );
}

