# AgriCommerce - E-commerce Platform untuk Bahan Pertanian

Platform e-commerce modern untuk perdagangan bahan pertanian dengan fitur lelang real-time, sistem escrow, dan chat real-time.

## 🚀 Fitur Utama

- **Frontend**: Next.js 14 dengan TypeScript, Tailwind CSS, PWA-ready
- **Backend**: NestJS dengan Prisma ORM dan PostgreSQL
- **Sistem Lelang**: Real-time auction dengan auto-bid dan anti-sniping
- **Escrow Payment**: Sistem pembayaran aman dengan rekening penampungan
- **Real-time Chat**: Komunikasi langsung antara buyer dan seller
- **Dashboard**: Panel kontrol untuk buyer, seller, dan admin

## 📁 Struktur Project

```
agri-ecommerce/
├── frontend/          # Next.js frontend application
├── backend/           # NestJS backend API
├── docs/             # Dokumentasi project
├── docker-compose.yml # Docker services configuration
└── README.md         # File ini
```

## 🛠 Tech Stack

### Frontend
- Next.js 14 (App Router)
- TypeScript
- Tailwind CSS
- PWA Support
- Socket.IO Client

### Backend
- NestJS
- Prisma ORM
- PostgreSQL
- Socket.IO
- JWT Authentication
- Bull Queue (Redis)

### Infrastructure
- PostgreSQL (Database)
- Redis (Cache & Queue)
- Meilisearch (Search Engine)
- MinIO (S3-compatible Object Storage)

## 🚀 Quick Start

1. **Clone dan Setup**
   ```bash
   git clone <repository-url>
   cd agri-ecommerce
   ```

2. **Start Services dengan Docker**
   ```bash
   docker-compose up -d
   ```

3. **Setup Backend**
   ```bash
   cd backend
   npm install
   npx prisma migrate dev
   npm run start:dev
   ```

4. **Setup Frontend**
   ```bash
   cd frontend
   npm install
   npm run dev
   ```

5. **Access Application**
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:3001
   - API Documentation: http://localhost:3001/api

## 📚 Dokumentasi

Lihat folder `docs/` untuk dokumentasi lengkap:
- [API Documentation](docs/api.md)
- [Database Schema](docs/database.md)
- [Deployment Guide](docs/deployment.md)

## 🤝 Contributing

1. Fork repository
2. Create feature branch
3. Commit changes
4. Push to branch
5. Create Pull Request

## 📄 License

MIT License - lihat file LICENSE untuk detail lengkap.

