# API Documentation - AgriCommerce

Dokumentasi lengkap untuk REST API AgriCommerce platform.

## 📖 Overview

AgriCommerce API menyediakan endpoints untuk:
- Authentication & User Management
- Product Management (CRUD)
- Auction System dengan Real-time Bidding
- Order Management dengan Escrow Payment
- Real-time Chat System
- File Upload & Management

**Base URL**: `http://localhost:3001/api/v1`

**API Documentation**: `http://localhost:3001/api` (Swagger)

## 🔐 Authentication

API menggunakan JWT (JSON Web Token) untuk authentication.

### Headers Required

```http
Authorization: Bearer <jwt_token>
Content-Type: application/json
```

## 📋 API Endpoints

### Authentication

#### Register User

```http
POST /auth/register
```

**Request Body:**
```json
{
  "email": "user@example.com",
  "username": "username123",
  "password": "password123",
  "firstName": "John",
  "lastName": "Doe",
  "phone": "+6281234567890",
  "role": "BUYER"
}
```

**Response:**
```json
{
  "user": {
    "id": "user-id",
    "email": "user@example.com",
    "username": "username123",
    "firstName": "John",
    "lastName": "Doe",
    "role": "BUYER",
    "status": "ACTIVE",
    "isVerified": false,
    "createdAt": "2024-01-01T00:00:00.000Z"
  },
  "token": "jwt-token-here",
  "message": "Registrasi berhasil"
}
```

#### Login User

```http
POST /auth/login
```

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "password123"
}
```

**Response:**
```json
{
  "user": {
    "id": "user-id",
    "email": "user@example.com",
    "username": "username123",
    "firstName": "John",
    "lastName": "Doe",
    "role": "BUYER",
    "status": "ACTIVE",
    "isVerified": false,
    "lastLoginAt": "2024-01-01T00:00:00.000Z",
    "sellerProfile": null
  },
  "token": "jwt-token-here",
  "message": "Login berhasil"
}
```

#### Get Current User Profile

```http
GET /auth/profile
```

**Headers:** `Authorization: Bearer <token>`

**Response:**
```json
{
  "id": "user-id",
  "email": "user@example.com",
  "username": "username123",
  "firstName": "John",
  "lastName": "Doe",
  "phone": "+6281234567890",
  "avatar": null,
  "role": "BUYER",
  "status": "ACTIVE",
  "isVerified": false,
  "createdAt": "2024-01-01T00:00:00.000Z",
  "sellerProfile": null
}
```

### Products

#### Create Product

```http
POST /products
```

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "name": "Beras Premium Organik",
  "description": "Beras organik berkualitas tinggi dari sawah terpilih",
  "categoryId": "category-id",
  "price": 15000,
  "stock": 100,
  "unit": "kg",
  "minOrder": 5,
  "images": ["/images/product1.jpg", "/images/product2.jpg"],
  "tags": ["organik", "premium", "bebas-pestisida"],
  "isAuctionable": true
}
```

**Response:**
```json
{
  "id": "product-id",
  "name": "Beras Premium Organik",
  "slug": "beras-premium-organik-1234567890",
  "description": "Beras organik berkualitas tinggi dari sawah terpilih",
  "price": 15000,
  "stock": 100,
  "unit": "kg",
  "minOrder": 5,
  "status": "DRAFT",
  "isAuctionable": true,
  "images": ["/images/product1.jpg", "/images/product2.jpg"],
  "tags": ["organik", "premium", "bebas-pestisida"],
  "createdAt": "2024-01-01T00:00:00.000Z",
  "updatedAt": "2024-01-01T00:00:00.000Z",
  "seller": {
    "id": "seller-id",
    "firstName": "Petani",
    "lastName": "Sukses",
    "username": "seller1"
  },
  "category": {
    "id": "category-id",
    "name": "Beras & Serealia",
    "slug": "beras-serealia"
  }
}
```

#### Get All Products

```http
GET /products?page=1&limit=10&categoryId=category-id&search=beras
```

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 10)
- `categoryId` (optional): Filter by category
- `search` (optional): Search in name, description, tags

**Response:**
```json
{
  "products": [
    {
      "id": "product-id",
      "name": "Beras Premium Organik",
      "slug": "beras-premium-organik-1234567890",
      "price": 15000,
      "stock": 100,
      "unit": "kg",
      "status": "ACTIVE",
      "images": ["/images/product1.jpg"],
      "createdAt": "2024-01-01T00:00:00.000Z",
      "seller": {
        "id": "seller-id",
        "firstName": "Petani",
        "lastName": "Sukses",
        "username": "seller1",
        "sellerProfile": {
          "businessName": "Tani Sukses Makmur",
          "rating": 4.8
        }
      },
      "category": {
        "id": "category-id",
        "name": "Beras & Serealia",
        "slug": "beras-serealia"
      },
      "_count": {
        "reviews": 24
      }
    }
  ],
  "pagination": {
    "page": 1,
    "limit": 10,
    "total": 50,
    "totalPages": 5
  }
}
```

#### Get Product by ID

```http
GET /products/:id
```

**Response:**
```json
{
  "id": "product-id",
  "name": "Beras Premium Organik",
  "slug": "beras-premium-organik-1234567890",
  "description": "Beras organik berkualitas tinggi dari sawah terpilih",
  "price": 15000,
  "stock": 100,
  "unit": "kg",
  "minOrder": 5,
  "status": "ACTIVE",
  "isAuctionable": true,
  "images": ["/images/product1.jpg", "/images/product2.jpg"],
  "tags": ["organik", "premium", "bebas-pestisida"],
  "createdAt": "2024-01-01T00:00:00.000Z",
  "updatedAt": "2024-01-01T00:00:00.000Z",
  "seller": {
    "id": "seller-id",
    "firstName": "Petani",
    "lastName": "Sukses",
    "username": "seller1",
    "sellerProfile": {
      "businessName": "Tani Sukses Makmur",
      "rating": 4.8,
      "totalSales": 150
    }
  },
  "category": {
    "id": "category-id",
    "name": "Beras & Serealia",
    "slug": "beras-serealia"
  },
  "reviews": [
    {
      "id": "review-id",
      "rating": 5,
      "comment": "Beras berkualitas tinggi, sangat puas!",
      "createdAt": "2024-01-01T00:00:00.000Z",
      "author": {
        "id": "buyer-id",
        "firstName": "Pembeli",
        "lastName": "Setia",
        "username": "buyer1"
      }
    }
  ],
  "_count": {
    "reviews": 24
  }
}
```

#### Update Product

```http
PATCH /products/:id
```

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "name": "Beras Premium Organik Updated",
  "price": 16000,
  "stock": 80,
  "status": "ACTIVE"
}
```

#### Delete Product

```http
DELETE /products/:id
```

**Headers:** `Authorization: Bearer <token>`

#### Get My Products (Seller)

```http
GET /products/my-products?page=1&limit=10
```

**Headers:** `Authorization: Bearer <token>`

### Auctions

#### Create Auction

```http
POST /auctions
```

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "productId": "product-id",
  "title": "Lelang Beras Premium Organik",
  "description": "Lelang beras organik berkualitas tinggi",
  "startingPrice": 10000,
  "reservePrice": 15000,
  "bidIncrement": 1000,
  "startTime": "2024-01-01T10:00:00Z",
  "endTime": "2024-01-02T10:00:00Z",
  "isAutoExtend": true,
  "extendMinutes": 5
}
```

**Response:**
```json
{
  "id": "auction-id",
  "title": "Lelang Beras Premium Organik",
  "description": "Lelang beras organik berkualitas tinggi",
  "startingPrice": 10000,
  "reservePrice": 15000,
  "currentPrice": 10000,
  "bidIncrement": 1000,
  "startTime": "2024-01-01T10:00:00Z",
  "endTime": "2024-01-02T10:00:00Z",
  "status": "DRAFT",
  "totalBids": 0,
  "winnerId": null,
  "isAutoExtend": true,
  "extendMinutes": 5,
  "createdAt": "2024-01-01T00:00:00.000Z",
  "product": {
    "id": "product-id",
    "name": "Beras Premium Organik",
    "images": ["/images/product1.jpg"]
  },
  "seller": {
    "id": "seller-id",
    "firstName": "Petani",
    "lastName": "Sukses",
    "username": "seller1"
  }
}
```

#### Place Bid

```http
POST /auctions/:id/bid
```

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "amount": 12000,
  "maxAmount": 20000,
  "isAuto": false
}
```

**Response:**
```json
{
  "bid": {
    "id": "bid-id",
    "amount": 12000,
    "maxAmount": 20000,
    "isAuto": false,
    "createdAt": "2024-01-01T00:00:00.000Z",
    "bidder": {
      "id": "bidder-id",
      "firstName": "Pembeli",
      "lastName": "Setia",
      "username": "buyer1"
    }
  },
  "auction": {
    "id": "auction-id",
    "currentPrice": 12000,
    "totalBids": 1,
    "endTime": "2024-01-02T10:00:00Z",
    "bids": [
      {
        "id": "bid-id",
        "amount": 12000,
        "createdAt": "2024-01-01T00:00:00.000Z",
        "bidder": {
          "id": "bidder-id",
          "firstName": "Pembeli",
          "lastName": "Setia",
          "username": "buyer1"
        }
      }
    ]
  },
  "message": "Bid berhasil ditempatkan"
}
```

#### Get All Auctions

```http
GET /auctions?page=1&limit=10&status=ACTIVE
```

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 10)
- `status` (optional): Filter by status (DRAFT, ACTIVE, ENDED, CANCELLED)

#### Get Auction by ID

```http
GET /auctions/:id
```

**Response:**
```json
{
  "id": "auction-id",
  "title": "Lelang Beras Premium Organik",
  "description": "Lelang beras organik berkualitas tinggi",
  "startingPrice": 10000,
  "reservePrice": 15000,
  "currentPrice": 12000,
  "bidIncrement": 1000,
  "startTime": "2024-01-01T10:00:00Z",
  "endTime": "2024-01-02T10:00:00Z",
  "status": "ACTIVE",
  "totalBids": 5,
  "winnerId": null,
  "isAutoExtend": true,
  "extendMinutes": 5,
  "createdAt": "2024-01-01T00:00:00.000Z",
  "product": {
    "id": "product-id",
    "name": "Beras Premium Organik",
    "description": "Beras organik berkualitas tinggi",
    "images": ["/images/product1.jpg", "/images/product2.jpg"],
    "unit": "kg",
    "stock": 100
  },
  "seller": {
    "id": "seller-id",
    "firstName": "Petani",
    "lastName": "Sukses",
    "username": "seller1",
    "sellerProfile": {
      "businessName": "Tani Sukses Makmur",
      "rating": 4.8
    }
  },
  "winner": null,
  "bids": [
    {
      "id": "bid-id",
      "amount": 12000,
      "isAuto": false,
      "createdAt": "2024-01-01T00:00:00.000Z",
      "bidder": {
        "id": "bidder-id",
        "firstName": "Pembeli",
        "lastName": "Setia",
        "username": "buyer1"
      }
    }
  ]
}
```

### Orders

#### Create Order (Checkout)

```http
POST /orders
```

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "sellerId": "seller-id",
  "items": [
    {
      "productId": "product-id",
      "quantity": 10,
      "price": 15000
    }
  ],
  "shippingCost": 25000,
  "notes": "Mohon dikemas dengan baik"
}
```

**Response:**
```json
{
  "id": "order-id",
  "orderNumber": "AGR-2024-001",
  "totalAmount": 150000,
  "shippingCost": 25000,
  "taxAmount": 0,
  "finalAmount": 175000,
  "status": "PENDING",
  "notes": "Mohon dikemas dengan baik",
  "createdAt": "2024-01-01T00:00:00.000Z",
  "buyer": {
    "id": "buyer-id",
    "firstName": "Pembeli",
    "lastName": "Setia"
  },
  "seller": {
    "id": "seller-id",
    "firstName": "Petani",
    "lastName": "Sukses"
  },
  "orderItems": [
    {
      "id": "item-id",
      "quantity": 10,
      "price": 15000,
      "total": 150000,
      "product": {
        "id": "product-id",
        "name": "Beras Premium Organik",
        "unit": "kg"
      }
    }
  ]
}
```

#### Get My Orders

```http
GET /orders/my-orders?page=1&limit=10&status=PENDING
```

**Headers:** `Authorization: Bearer <token>`

**Query Parameters:**
- `page` (optional): Page number (default: 1)
- `limit` (optional): Items per page (default: 10)
- `status` (optional): Filter by status

#### Get Order by ID

```http
GET /orders/:id
```

**Headers:** `Authorization: Bearer <token>`

#### Update Order Status

```http
PATCH /orders/:id/status
```

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "status": "CONFIRMED"
}
```

### Payments

#### Create Payment

```http
POST /payments
```

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "orderId": "order-id",
  "amount": 175000,
  "method": "bank_transfer",
  "receipt": "/uploads/receipt.jpg"
}
```

#### Get Payment by Order

```http
GET /payments/order/:orderId
```

**Headers:** `Authorization: Bearer <token>`

### Escrow

#### Create Escrow Transaction

```http
POST /escrow
```

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "orderId": "order-id",
  "amount": 175000
}
```

#### Release Escrow

```http
POST /escrow/:id/release
```

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "releaseNotes": "Barang sudah diterima dengan baik"
}
```

#### Refund Escrow

```http
POST /escrow/:id/refund
```

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "reason": "Barang tidak sesuai pesanan"
}
```

### Chat

#### Get My Chats

```http
GET /chat
```

**Headers:** `Authorization: Bearer <token>`

#### Create or Get Chat

```http
POST /chat
```

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "receiverId": "user-id"
}
```

#### Send Message

```http
POST /chat/:chatId/messages
```

**Headers:** `Authorization: Bearer <token>`

**Request Body:**
```json
{
  "content": "Halo, apakah produk masih tersedia?",
  "type": "text"
}
```

#### Get Chat Messages

```http
GET /chat/:chatId/messages?page=1&limit=50
```

**Headers:** `Authorization: Bearer <token>`

## 🔄 Real-time Events

### WebSocket Connection

```javascript
import io from 'socket.io-client';

const socket = io('http://localhost:3001', {
  auth: {
    token: 'jwt-token-here'
  }
});
```

### Auction Events

```javascript
// Join auction room
socket.emit('join-auction', auctionId);

// Listen for bid updates
socket.on('bid-update', (data) => {
  console.log('New bid:', data);
});

// Listen for auction end
socket.on('auction-end', (data) => {
  console.log('Auction ended:', data);
});
```

### Chat Events

```javascript
// Join chat room
socket.emit('join-chat', chatId);

// Send message
socket.emit('send-message', {
  chatId,
  content: 'Hello!',
  type: 'text'
});

// Listen for new messages
socket.on('new-message', (message) => {
  console.log('New message:', message);
});
```

## 📊 Response Codes

| Code | Status | Description |
|------|--------|-------------|
| 200 | OK | Request successful |
| 201 | Created | Resource created successfully |
| 400 | Bad Request | Invalid request data |
| 401 | Unauthorized | Authentication required |
| 403 | Forbidden | Access denied |
| 404 | Not Found | Resource not found |
| 409 | Conflict | Resource already exists |
| 422 | Unprocessable Entity | Validation error |
| 500 | Internal Server Error | Server error |

## 🔍 Error Handling

### Error Response Format

```json
{
  "statusCode": 400,
  "message": "Validation failed",
  "error": "Bad Request",
  "details": [
    {
      "field": "email",
      "message": "Email must be a valid email address"
    }
  ]
}
```

### Common Errors

#### Validation Error (422)

```json
{
  "statusCode": 422,
  "message": "Validation failed",
  "error": "Unprocessable Entity",
  "details": [
    {
      "field": "price",
      "message": "Price must be a positive number"
    }
  ]
}
```

#### Authentication Error (401)

```json
{
  "statusCode": 401,
  "message": "Unauthorized",
  "error": "Unauthorized"
}
```

#### Not Found Error (404)

```json
{
  "statusCode": 404,
  "message": "Product not found",
  "error": "Not Found"
}
```

## 📝 Rate Limiting

API menggunakan rate limiting untuk mencegah abuse:

- **Authentication endpoints**: 5 requests per minute
- **General endpoints**: 100 requests per minute
- **File upload**: 10 requests per minute

## 🔐 Security

### CORS

API dikonfigurasi untuk menerima request dari:
- `http://localhost:3000` (development)
- Domain production yang dikonfigurasi

### Input Validation

Semua input divalidasi menggunakan:
- **class-validator** untuk DTO validation
- **Prisma** untuk database constraints
- **Custom validators** untuk business logic

### File Upload Security

- **File type validation**: Hanya file yang diizinkan
- **File size limit**: Maximum 10MB per file
- **Virus scanning**: Implementasi antivirus scanning
- **Secure storage**: File disimpan di MinIO dengan access control

## 📚 SDK & Libraries

### JavaScript/TypeScript

```bash
npm install axios socket.io-client
```

```javascript
import axios from 'axios';
import io from 'socket.io-client';

const api = axios.create({
  baseURL: 'http://localhost:3001/api/v1',
  headers: {
    'Content-Type': 'application/json'
  }
});

// Add auth token to requests
api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});
```

### React Hooks

```javascript
import { useState, useEffect } from 'react';
import axios from 'axios';

export const useProducts = (page = 1, limit = 10) => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchProducts = async () => {
      try {
        setLoading(true);
        const response = await axios.get(`/products?page=${page}&limit=${limit}`);
        setProducts(response.data.products);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, [page, limit]);

  return { products, loading, error };
};
```

## 🧪 Testing

### API Testing dengan Postman

Import collection: `docs/postman/AgriCommerce.postman_collection.json`

### cURL Examples

```bash
# Register user
curl -X POST http://localhost:3001/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "username": "testuser",
    "password": "password123",
    "firstName": "Test",
    "lastName": "User"
  }'

# Login user
curl -X POST http://localhost:3001/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "test@example.com",
    "password": "password123"
  }'

# Get products
curl -X GET http://localhost:3001/api/v1/products \
  -H "Authorization: Bearer <token>"
```

## 📈 Performance

### Caching

API menggunakan Redis untuk caching:
- **Product listings**: Cache 5 minutes
- **User sessions**: Cache until logout
- **Search results**: Cache 2 minutes

### Database Optimization

- **Indexes**: Optimized database indexes
- **Query optimization**: Efficient Prisma queries
- **Connection pooling**: Database connection pooling

### Rate Limiting

Implementasi rate limiting untuk mencegah abuse dan menjaga performa server.

## 🔄 Versioning

API menggunakan URL versioning:
- **Current version**: v1
- **Base URL**: `/api/v1`
- **Backward compatibility**: Maintained for 1 year

## 📞 Support

Untuk bantuan teknis:
- **Documentation**: http://localhost:3001/api
- **GitHub Issues**: Create issue dengan label 'api'
- **Email**: api-support@agricommerce.com

