import { IsString, IsNumber, IsDate, IsOptional, IsBoolean, Min } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';

export class CreateAuctionDto {
  @ApiProperty({ example: 'product-id-here' })
  @IsString()
  productId: string;

  @ApiProperty({ example: 'Lelang Beras Premium Organik' })
  @IsString()
  title: string;

  @ApiProperty({ example: 'Lelang beras organik berkualitas tinggi' })
  @IsOptional()
  @IsString()
  description?: string;

  @ApiProperty({ example: 10000 })
  @IsNumber()
  @Min(0)
  startingPrice: number;

  @ApiProperty({ example: 15000 })
  @IsOptional()
  @IsNumber()
  @Min(0)
  reservePrice?: number;

  @ApiProperty({ example: 1000 })
  @IsOptional()
  @IsNumber()
  @Min(1)
  bidIncrement?: number;

  @ApiProperty({ example: '2024-01-01T10:00:00Z' })
  @IsDate()
  @Type(() => Date)
  startTime: Date;

  @ApiProperty({ example: '2024-01-02T10:00:00Z' })
  @IsDate()
  @Type(() => Date)
  endTime: Date;

  @ApiProperty({ example: true })
  @IsOptional()
  @IsBoolean()
  isAutoExtend?: boolean;

  @ApiProperty({ example: 5 })
  @IsOptional()
  @IsNumber()
  @Min(1)
  extendMinutes?: number;
}

