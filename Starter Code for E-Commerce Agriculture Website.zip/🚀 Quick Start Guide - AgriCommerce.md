# 🚀 Quick Start Guide - AgriCommerce

Panduan cepat untuk menjalankan AgriCommerce dalam 5 menit!

## ⚡ Prerequisites

- Node.js v18+
- Docker & Docker Compose
- Git

## 🏃‍♂️ Quick Setup

### 1. Clone & Setup

```bash
git clone <repository-url>
cd agri-ecommerce
cp .env.development .env
```

### 2. Start Services

```bash
# Start database & services
docker-compose up -d

# Wait for services to be ready (30 seconds)
sleep 30
```

### 3. Setup Backend

```bash
cd backend
npm install
npx prisma generate
npx prisma migrate dev
npx prisma db seed
npm run start:dev
```

### 4. Setup Frontend (New Terminal)

```bash
cd frontend
npm install
npm run dev
```

## 🎯 Access Application

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:3001
- **API Docs**: http://localhost:3001/api
- **Database Admin**: http://localhost:8080
- **Redis Admin**: http://localhost:8081

## 🧪 Test Accounts

### Admin
- Email: `admin@agricommerce.com`
- Password: `password123`

### Seller
- Email: `seller@agricommerce.com`
- Password: `password123`

### Buyer
- Email: `buyer@agricommerce.com`
- Password: `password123`

## 🔧 Development Commands

### Backend
```bash
cd backend
npm run start:dev    # Development server
npm run build        # Build for production
npm run test         # Run tests
npx prisma studio    # Database GUI
```

### Frontend
```bash
cd frontend
npm run dev          # Development server
npm run build        # Build for production
npm run start        # Production server
```

### Docker
```bash
docker-compose up -d              # Start all services
docker-compose down               # Stop all services
docker-compose logs -f <service>  # View logs
docker-compose ps                 # Check status
```

## 🚨 Troubleshooting

### Port Already in Use
```bash
# Kill processes on ports
sudo lsof -ti:3000 | xargs kill -9
sudo lsof -ti:3001 | xargs kill -9
sudo lsof -ti:5432 | xargs kill -9
```

### Database Issues
```bash
# Reset database
cd backend
npx prisma migrate reset
npx prisma db seed
```

### Docker Issues
```bash
# Clean restart
docker-compose down -v
docker-compose up -d
```

## 📚 Next Steps

1. **Explore Features**: Coba fitur-fitur utama aplikasi
2. **Read Documentation**: Baca dokumentasi lengkap di `docs/`
3. **API Testing**: Test API endpoints di http://localhost:3001/api
4. **Customize**: Sesuaikan konfigurasi sesuai kebutuhan

## 🆘 Need Help?

- 📖 **Full Documentation**: `docs/INSTALLATION.md`
- 🔧 **API Reference**: `docs/API.md`
- 🚀 **Deployment Guide**: `docs/DEPLOYMENT.md`
- 🐛 **Issues**: Create GitHub issue

---

**Happy Coding! 🎉**

