import { Module } from '@nestjs/common';
import { BullModule } from '@nestjs/bull';
import { AuctionsController } from './auctions.controller';
import { AuctionsService } from './auctions.service';
import { AuctionProcessor } from './auction.processor';
import { AuctionGateway } from './auction.gateway';

@Module({
  imports: [
    BullModule.registerQueue({
      name: 'auction',
    }),
  ],
  controllers: [AuctionsController],
  providers: [AuctionsService, AuctionProcessor, AuctionGateway],
  exports: [AuctionsService],
})
export class AuctionsModule {}

