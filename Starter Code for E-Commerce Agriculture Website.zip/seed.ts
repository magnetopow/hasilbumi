import { PrismaClient, UserRole } from '@prisma/client';
import * as bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  console.log('🌱 Seeding database...');

  // Hash password untuk demo users
  const hashedPassword = await bcrypt.hash('password123', 10);

  // Create admin user
  const admin = await prisma.user.upsert({
    where: { email: 'admin@agricommerce.com' },
    update: {},
    create: {
      email: 'admin@agricommerce.com',
      username: 'admin',
      password: hashedPassword,
      firstName: 'Admin',
      lastName: 'AgriCommerce',
      role: UserRole.ADMIN,
      isVerified: true,
    },
  });

  // Create seller user
  const seller = await prisma.user.upsert({
    where: { email: 'seller@agricommerce.com' },
    update: {},
    create: {
      email: 'seller@agricommerce.com',
      username: 'seller1',
      password: hashedPassword,
      firstName: 'Petani',
      lastName: 'Sukses',
      role: UserRole.SELLER,
      isVerified: true,
    },
  });

  // Create seller profile
  await prisma.sellerProfile.upsert({
    where: { userId: seller.id },
    update: {},
    create: {
      userId: seller.id,
      businessName: 'Tani Sukses Makmur',
      businessType: 'Pertanian Organik',
      businessAddress: 'Jl. Raya Pertanian No. 123, Bogor',
      businessPhone: '+62812345678',
      businessEmail: 'business@tanisukses.com',
      taxId: '123456789012345',
      bankAccount: '1234567890',
      bankName: 'Bank Mandiri',
      accountHolder: 'Petani Sukses',
      isVerified: true,
      rating: 4.8,
      totalSales: 150,
    },
  });

  // Create buyer user
  const buyer = await prisma.user.upsert({
    where: { email: 'buyer@agricommerce.com' },
    update: {},
    create: {
      email: 'buyer@agricommerce.com',
      username: 'buyer1',
      password: hashedPassword,
      firstName: 'Pembeli',
      lastName: 'Setia',
      role: UserRole.BUYER,
      isVerified: true,
    },
  });

  // Create categories
  const categories = [
    {
      name: 'Beras & Serealia',
      slug: 'beras-serealia',
      description: 'Beras, jagung, gandum, dan serealia lainnya',
    },
    {
      name: 'Sayuran',
      slug: 'sayuran',
      description: 'Sayuran segar dan organik',
    },
    {
      name: 'Buah-buahan',
      slug: 'buah-buahan',
      description: 'Buah segar dan berkualitas',
    },
    {
      name: 'Rempah & Bumbu',
      slug: 'rempah-bumbu',
      description: 'Rempah-rempah dan bumbu dapur',
    },
    {
      name: 'Pupuk & Pestisida',
      slug: 'pupuk-pestisida',
      description: 'Pupuk organik dan pestisida alami',
    },
  ];

  for (const category of categories) {
    await prisma.category.upsert({
      where: { slug: category.slug },
      update: {},
      create: category,
    });
  }

  // Get created categories
  const berasCategory = await prisma.category.findUnique({
    where: { slug: 'beras-serealia' },
  });

  const sayuranCategory = await prisma.category.findUnique({
    where: { slug: 'sayuran' },
  });

  // Create sample products
  const products = [
    {
      sellerId: seller.id,
      categoryId: berasCategory!.id,
      name: 'Beras Premium Organik',
      slug: 'beras-premium-organik',
      description: 'Beras organik berkualitas tinggi dari sawah terpilih. Bebas pestisida dan pupuk kimia.',
      images: ['/images/beras-organik-1.jpg', '/images/beras-organik-2.jpg'],
      price: 15000,
      stock: 500,
      unit: 'kg',
      minOrder: 5,
      status: 'ACTIVE',
      isAuctionable: true,
      tags: ['organik', 'premium', 'bebas-pestisida'],
    },
    {
      sellerId: seller.id,
      categoryId: sayuranCategory!.id,
      name: 'Tomat Cherry Organik',
      slug: 'tomat-cherry-organik',
      description: 'Tomat cherry segar dan manis, ditanam secara organik tanpa bahan kimia berbahaya.',
      images: ['/images/tomat-cherry-1.jpg', '/images/tomat-cherry-2.jpg'],
      price: 25000,
      stock: 100,
      unit: 'kg',
      minOrder: 2,
      status: 'ACTIVE',
      isAuctionable: false,
      tags: ['organik', 'segar', 'tomat'],
    },
  ];

  for (const product of products) {
    await prisma.product.upsert({
      where: { slug: product.slug },
      update: {},
      create: product,
    });
  }

  console.log('✅ Database seeded successfully!');
}

main()
  .catch((e) => {
    console.error('❌ Error seeding database:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });

