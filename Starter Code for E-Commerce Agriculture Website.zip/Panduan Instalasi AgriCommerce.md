# Panduan Instalasi AgriCommerce

Panduan lengkap untuk menginstal dan menjalankan platform AgriCommerce di lingkungan development dan production.

## 📋 Prerequisites

Sebelum memulai instalasi, pastikan sistem Anda memiliki:

### Software Requirements
- **Node.js** v18.0.0 atau lebih tinggi
- **npm** v8.0.0 atau lebih tinggi (atau **yarn** v1.22.0+)
- **Docker** v20.10.0 atau lebih tinggi
- **Docker Compose** v2.0.0 atau lebih tinggi
- **Git** untuk version control

### Hardware Requirements
- **RAM**: Minimum 4GB, Recommended 8GB+
- **Storage**: Minimum 10GB free space
- **CPU**: 2 cores minimum, 4 cores recommended

## 🚀 Quick Start

### 1. Clone Repository

```bash
git clone <repository-url>
cd agri-ecommerce
```

### 2. Setup Environment Variables

```bash
# Copy environment file
cp .env.development .env

# Edit environment variables sesuai kebutuhan
nano .env
```

### 3. Start Services dengan Docker

```bash
# Start all services
docker-compose up -d

# Verify services are running
docker-compose ps
```

### 4. Setup Backend

```bash
cd backend

# Install dependencies
npm install

# Copy environment file
cp .env.example .env

# Generate Prisma client
npx prisma generate

# Run database migrations
npx prisma migrate dev

# Seed database with sample data
npx prisma db seed

# Start development server
npm run start:dev
```

### 5. Setup Frontend

```bash
cd frontend

# Install dependencies
npm install

# Start development server
npm run dev
```

### 6. Access Application

- **Frontend**: http://localhost:3000
- **Backend API**: http://localhost:3001
- **API Documentation**: http://localhost:3001/api
- **Database Admin**: http://localhost:8080 (Adminer)
- **Redis Admin**: http://localhost:8081 (Redis Commander)
- **Meilisearch**: http://localhost:7700
- **MinIO Console**: http://localhost:9001

## 🔧 Detailed Installation

### Backend Setup

#### 1. Install Dependencies

```bash
cd backend
npm install
```

#### 2. Environment Configuration

Buat file `.env` dari template:

```bash
cp .env.example .env
```

Edit file `.env` dan sesuaikan konfigurasi:

```env
# Database
DATABASE_URL="postgresql://postgres:password@localhost:5432/agricommerce?schema=public"

# JWT
JWT_SECRET="your-super-secret-jwt-key-here"
JWT_EXPIRES_IN="7d"

# Redis
REDIS_HOST="localhost"
REDIS_PORT=6379

# Meilisearch
MEILISEARCH_HOST="http://localhost:7700"
MEILISEARCH_API_KEY="masterKey123456789"

# MinIO
MINIO_ENDPOINT="localhost"
MINIO_PORT=9000
MINIO_ACCESS_KEY="minioadmin"
MINIO_SECRET_KEY="minioadmin123"
MINIO_BUCKET="agricommerce"

# App Configuration
APP_PORT=3001
APP_HOST="0.0.0.0"
NODE_ENV="development"
CORS_ORIGIN="http://localhost:3000"
```

#### 3. Database Setup

```bash
# Generate Prisma client
npx prisma generate

# Create and run migrations
npx prisma migrate dev --name init

# Seed database with sample data
npx prisma db seed
```

#### 4. Start Backend Server

```bash
# Development mode
npm run start:dev

# Production mode
npm run build
npm run start:prod
```

### Frontend Setup

#### 1. Install Dependencies

```bash
cd frontend
npm install
```

#### 2. Environment Configuration

Buat file `.env.local`:

```bash
# Frontend Environment
NEXT_PUBLIC_API_URL=http://localhost:3001/api/v1
NEXT_PUBLIC_WS_URL=http://localhost:3001
NEXT_PUBLIC_MINIO_URL=http://localhost:9000
```

#### 3. Start Frontend Server

```bash
# Development mode
npm run dev

# Build for production
npm run build
npm run start
```

### Docker Services Setup

#### 1. Start All Services

```bash
# Start in background
docker-compose up -d

# Start with logs
docker-compose up
```

#### 2. Individual Service Management

```bash
# Start specific service
docker-compose up -d postgres

# Stop specific service
docker-compose stop postgres

# Restart service
docker-compose restart postgres

# View logs
docker-compose logs -f postgres
```

#### 3. Service Health Check

```bash
# Check all services status
docker-compose ps

# Check specific service logs
docker-compose logs minio
```

## 🔍 Troubleshooting

### Common Issues

#### 1. Port Already in Use

```bash
# Check what's using the port
lsof -i :3000
lsof -i :3001
lsof -i :5432

# Kill process using port
kill -9 <PID>
```

#### 2. Database Connection Issues

```bash
# Check PostgreSQL is running
docker-compose ps postgres

# Check database logs
docker-compose logs postgres

# Connect to database manually
docker-compose exec postgres psql -U postgres -d agricommerce
```

#### 3. Redis Connection Issues

```bash
# Check Redis is running
docker-compose ps redis

# Test Redis connection
docker-compose exec redis redis-cli ping
```

#### 4. MinIO Access Issues

```bash
# Check MinIO is running
docker-compose ps minio

# Check MinIO logs
docker-compose logs minio

# Access MinIO console
# http://localhost:9001
# Username: minioadmin
# Password: minioadmin123
```

### Performance Issues

#### 1. Slow Database Queries

```bash
# Enable query logging in Prisma
# Add to schema.prisma:
# log: ["query", "info", "warn", "error"]
```

#### 2. Memory Issues

```bash
# Check Docker memory usage
docker stats

# Increase Docker memory limit
# Docker Desktop > Settings > Resources > Memory
```

### Development Issues

#### 1. TypeScript Errors

```bash
# Check TypeScript configuration
npx tsc --noEmit

# Clear Next.js cache
rm -rf .next
npm run dev
```

#### 2. Prisma Issues

```bash
# Reset database
npx prisma migrate reset

# Regenerate client
npx prisma generate

# View database in browser
npx prisma studio
```

## 🧪 Testing

### Backend Testing

```bash
cd backend

# Run unit tests
npm run test

# Run e2e tests
npm run test:e2e

# Run tests with coverage
npm run test:cov
```

### Frontend Testing

```bash
cd frontend

# Run tests
npm run test

# Run tests in watch mode
npm run test:watch
```

## 📊 Monitoring

### Application Logs

```bash
# Backend logs
cd backend
npm run start:dev

# Frontend logs
cd frontend
npm run dev

# Docker services logs
docker-compose logs -f
```

### Database Monitoring

```bash
# Access Adminer
# http://localhost:8080
# Server: postgres
# Username: postgres
# Password: password
# Database: agricommerce
```

### Redis Monitoring

```bash
# Access Redis Commander
# http://localhost:8081
```

### Search Engine Monitoring

```bash
# Access Meilisearch dashboard
# http://localhost:7700
# Master Key: masterKey123456789
```

## 🔐 Security

### Development Security

1. **Environment Variables**: Jangan commit file `.env` ke repository
2. **JWT Secret**: Gunakan secret key yang kuat untuk production
3. **Database**: Gunakan password yang kuat untuk database
4. **CORS**: Konfigurasi CORS dengan benar untuk production

### Production Security

1. **HTTPS**: Selalu gunakan HTTPS di production
2. **Firewall**: Konfigurasi firewall untuk membatasi akses
3. **Database**: Gunakan SSL connection untuk database
4. **Secrets**: Gunakan secret management service
5. **Updates**: Selalu update dependencies secara berkala

## 📝 Next Steps

Setelah instalasi berhasil:

1. **Baca dokumentasi API**: http://localhost:3001/api
2. **Explore database schema**: `docs/DATABASE.md`
3. **Pelajari arsitektur**: `docs/ARCHITECTURE.md`
4. **Setup deployment**: `docs/DEPLOYMENT.md`
5. **Kontribusi**: `CONTRIBUTING.md`

## 🆘 Getting Help

Jika mengalami masalah:

1. **Check logs**: Periksa log aplikasi dan Docker
2. **Search issues**: Cari di GitHub issues
3. **Create issue**: Buat issue baru dengan detail lengkap
4. **Contact team**: Hubungi tim development

## 📚 Additional Resources

- [Next.js Documentation](https://nextjs.org/docs)
- [NestJS Documentation](https://docs.nestjs.com)
- [Prisma Documentation](https://www.prisma.io/docs)
- [Docker Documentation](https://docs.docker.com)
- [PostgreSQL Documentation](https://www.postgresql.org/docs)
- [Redis Documentation](https://redis.io/documentation)
- [Meilisearch Documentation](https://docs.meilisearch.com)
- [MinIO Documentation](https://docs.min.io)

