import { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { ClockIcon, UserGroupIcon } from '@heroicons/react/24/outline';

interface AuctionCardProps {
  auction: {
    id: string;
    title: string;
    currentPrice: number;
    endTime: Date;
    totalBids: number;
    product: {
      name: string;
      images: string[];
    };
  };
}

export function AuctionCard({ auction }: AuctionCardProps) {
  const [timeLeft, setTimeLeft] = useState('');

  useEffect(() => {
    const calculateTimeLeft = () => {
      const now = new Date().getTime();
      const endTime = new Date(auction.endTime).getTime();
      const difference = endTime - now;

      if (difference > 0) {
        const days = Math.floor(difference / (1000 * 60 * 60 * 24));
        const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((difference % (1000 * 60)) / 1000);

        if (days > 0) {
          setTimeLeft(`${days}h ${hours}j ${minutes}m`);
        } else if (hours > 0) {
          setTimeLeft(`${hours}j ${minutes}m ${seconds}d`);
        } else if (minutes > 0) {
          setTimeLeft(`${minutes}m ${seconds}d`);
        } else {
          setTimeLeft(`${seconds}d`);
        }
      } else {
        setTimeLeft('Berakhir');
      }
    };

    calculateTimeLeft();
    const timer = setInterval(calculateTimeLeft, 1000);

    return () => clearInterval(timer);
  }, [auction.endTime]);

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
    }).format(price);
  };

  const isEnding = () => {
    const now = new Date().getTime();
    const endTime = new Date(auction.endTime).getTime();
    const difference = endTime - now;
    return difference < 60 * 60 * 1000; // Less than 1 hour
  };

  return (
    <div className="card hover:shadow-lg transition-shadow duration-200">
      <Link href={`/auctions/${auction.id}`}>
        <div className="relative aspect-video mb-4 overflow-hidden rounded-lg bg-gray-100">
          {auction.product.images && auction.product.images.length > 0 ? (
            <Image
              src={auction.product.images[0]}
              alt={auction.product.name}
              fill
              className="object-cover hover:scale-105 transition-transform duration-200"
              sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gray-200">
              <span className="text-gray-400">No Image</span>
            </div>
          )}
          
          {/* Status badge */}
          <div className="absolute top-2 left-2">
            <span className={`badge ${isEnding() ? 'badge-red' : 'badge-green'}`}>
              {isEnding() ? 'Segera Berakhir' : 'Aktif'}
            </span>
          </div>
        </div>
      </Link>

      <div className="space-y-3">
        <Link href={`/auctions/${auction.id}`}>
          <h3 className="font-semibold text-gray-900 hover:text-primary-600 transition-colors line-clamp-2">
            {auction.title}
          </h3>
        </Link>

        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm text-gray-600">Bid Tertinggi:</span>
            <span className="text-lg font-bold text-primary-600">
              {formatPrice(auction.currentPrice)}
            </span>
          </div>

          <div className="flex items-center justify-between text-sm text-gray-600">
            <div className="flex items-center space-x-1">
              <UserGroupIcon className="h-4 w-4" />
              <span>{auction.totalBids} bid</span>
            </div>
            <div className={`flex items-center space-x-1 ${isEnding() ? 'text-red-600' : ''}`}>
              <ClockIcon className="h-4 w-4" />
              <span className="font-medium">{timeLeft}</span>
            </div>
          </div>
        </div>

        <Link
          href={`/auctions/${auction.id}`}
          className="w-full btn-primary text-sm py-2 mt-3 block text-center"
        >
          Ikut Lelang
        </Link>
      </div>
    </div>
  );
}

