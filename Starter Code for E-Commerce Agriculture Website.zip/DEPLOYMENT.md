# Deployment Guide - AgriCommerce

Panduan lengkap untuk deploy AgriCommerce ke production environment.

## 🚀 Production Deployment

### Prerequisites

- **Server**: Ubuntu 20.04+ atau CentOS 8+
- **RAM**: Minimum 4GB, Recommended 8GB+
- **Storage**: Minimum 50GB SSD
- **CPU**: 2 cores minimum, 4 cores recommended
- **Domain**: Domain name dengan SSL certificate
- **Docker**: Docker & Docker Compose installed

### 1. Server Setup

#### Update System

```bash
sudo apt update && sudo apt upgrade -y
sudo apt install -y curl wget git nginx certbot python3-certbot-nginx
```

#### Install Docker

```bash
# Install Docker
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker $USER

# Install Docker Compose
sudo curl -L "https://github.com/docker/compose/releases/download/v2.20.0/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# Verify installation
docker --version
docker-compose --version
```

#### Setup Firewall

```bash
sudo ufw allow ssh
sudo ufw allow 80
sudo ufw allow 443
sudo ufw enable
```

### 2. Application Deployment

#### Clone Repository

```bash
cd /opt
sudo git clone <repository-url> agricommerce
sudo chown -R $USER:$USER /opt/agricommerce
cd /opt/agricommerce
```

#### Environment Configuration

```bash
# Copy production environment
cp .env.development .env.production

# Edit production environment
nano .env.production
```

**Production Environment Variables:**

```env
# Database
DATABASE_URL="postgresql://postgres:STRONG_PASSWORD@localhost:5432/agricommerce?schema=public"

# JWT
JWT_SECRET="VERY_STRONG_JWT_SECRET_KEY_FOR_PRODUCTION"
JWT_EXPIRES_IN="7d"

# Redis
REDIS_HOST="localhost"
REDIS_PORT=6379
REDIS_PASSWORD="STRONG_REDIS_PASSWORD"

# Meilisearch
MEILISEARCH_HOST="http://localhost:7700"
MEILISEARCH_API_KEY="STRONG_MEILISEARCH_KEY"

# MinIO
MINIO_ENDPOINT="localhost"
MINIO_PORT=9000
MINIO_ACCESS_KEY="STRONG_MINIO_ACCESS_KEY"
MINIO_SECRET_KEY="STRONG_MINIO_SECRET_KEY"
MINIO_BUCKET="agricommerce"
MINIO_USE_SSL=false

# App Configuration
APP_PORT=3001
APP_HOST="0.0.0.0"
NODE_ENV="production"

# CORS
CORS_ORIGIN="https://yourdomain.com"

# Frontend
NEXT_PUBLIC_API_URL="https://api.yourdomain.com/api/v1"
NEXT_PUBLIC_WS_URL="https://api.yourdomain.com"
NEXT_PUBLIC_MINIO_URL="https://storage.yourdomain.com"

# SSL/TLS
SSL_CERT_PATH="/etc/letsencrypt/live/yourdomain.com/fullchain.pem"
SSL_KEY_PATH="/etc/letsencrypt/live/yourdomain.com/privkey.pem"
```

#### Docker Production Configuration

Create `docker-compose.prod.yml`:

```yaml
version: '3.8'

services:
  postgres:
    image: postgres:15-alpine
    container_name: agricommerce-postgres-prod
    restart: always
    environment:
      POSTGRES_DB: agricommerce
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: ${POSTGRES_PASSWORD}
      PGDATA: /var/lib/postgresql/data/pgdata
    volumes:
      - postgres_data:/var/lib/postgresql/data
      - ./backup:/backup
    networks:
      - agricommerce-network
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U postgres -d agricommerce"]
      interval: 30s
      timeout: 10s
      retries: 5

  redis:
    image: redis:7-alpine
    container_name: agricommerce-redis-prod
    restart: always
    command: redis-server --requirepass ${REDIS_PASSWORD}
    volumes:
      - redis_data:/data
    networks:
      - agricommerce-network
    healthcheck:
      test: ["CMD", "redis-cli", "--no-auth-warning", "-a", "${REDIS_PASSWORD}", "ping"]
      interval: 30s
      timeout: 10s
      retries: 5

  meilisearch:
    image: getmeili/meilisearch:v1.4
    container_name: agricommerce-meilisearch-prod
    restart: always
    environment:
      MEILI_ENV: production
      MEILI_MASTER_KEY: ${MEILISEARCH_API_KEY}
      MEILI_NO_ANALYTICS: true
    volumes:
      - meilisearch_data:/meili_data
    networks:
      - agricommerce-network
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:7700/health"]
      interval: 30s
      timeout: 10s
      retries: 5

  minio:
    image: minio/minio:latest
    container_name: agricommerce-minio-prod
    restart: always
    environment:
      MINIO_ROOT_USER: ${MINIO_ACCESS_KEY}
      MINIO_ROOT_PASSWORD: ${MINIO_SECRET_KEY}
      MINIO_CONSOLE_ADDRESS: ":9001"
    volumes:
      - minio_data:/data
    networks:
      - agricommerce-network
    command: server /data
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:9000/minio/health/live"]
      interval: 30s
      timeout: 20s
      retries: 3

  backend:
    build:
      context: ./backend
      dockerfile: Dockerfile.prod
    container_name: agricommerce-backend-prod
    restart: always
    environment:
      - NODE_ENV=production
    env_file:
      - .env.production
    depends_on:
      postgres:
        condition: service_healthy
      redis:
        condition: service_healthy
      meilisearch:
        condition: service_healthy
      minio:
        condition: service_healthy
    networks:
      - agricommerce-network
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3001/api/v1"]
      interval: 30s
      timeout: 10s
      retries: 5

  frontend:
    build:
      context: ./frontend
      dockerfile: Dockerfile.prod
    container_name: agricommerce-frontend-prod
    restart: always
    environment:
      - NODE_ENV=production
    env_file:
      - .env.production
    depends_on:
      backend:
        condition: service_healthy
    networks:
      - agricommerce-network
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:3000"]
      interval: 30s
      timeout: 10s
      retries: 5

volumes:
  postgres_data:
  redis_data:
  meilisearch_data:
  minio_data:

networks:
  agricommerce-network:
    driver: bridge
```

#### Create Dockerfiles

**Backend Dockerfile (`backend/Dockerfile.prod`):**

```dockerfile
FROM node:18-alpine AS builder

WORKDIR /app

# Copy package files
COPY package*.json ./
COPY prisma ./prisma/

# Install dependencies
RUN npm ci --only=production && npm cache clean --force

# Generate Prisma client
RUN npx prisma generate

# Copy source code
COPY . .

# Build application
RUN npm run build

# Production stage
FROM node:18-alpine AS production

WORKDIR /app

# Install dumb-init
RUN apk add --no-cache dumb-init

# Create non-root user
RUN addgroup -g 1001 -S nodejs
RUN adduser -S nestjs -u 1001

# Copy built application
COPY --from=builder --chown=nestjs:nodejs /app/dist ./dist
COPY --from=builder --chown=nestjs:nodejs /app/node_modules ./node_modules
COPY --from=builder --chown=nestjs:nodejs /app/prisma ./prisma
COPY --from=builder --chown=nestjs:nodejs /app/package*.json ./

USER nestjs

EXPOSE 3001

ENTRYPOINT ["dumb-init", "--"]
CMD ["node", "dist/main"]
```

**Frontend Dockerfile (`frontend/Dockerfile.prod`):**

```dockerfile
FROM node:18-alpine AS builder

WORKDIR /app

# Copy package files
COPY package*.json ./

# Install dependencies
RUN npm ci --only=production && npm cache clean --force

# Copy source code
COPY . .

# Build application
RUN npm run build

# Production stage
FROM node:18-alpine AS production

WORKDIR /app

# Install dumb-init
RUN apk add --no-cache dumb-init

# Create non-root user
RUN addgroup -g 1001 -S nodejs
RUN adduser -S nextjs -u 1001

# Copy built application
COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static
COPY --from=builder --chown=nextjs:nodejs /app/public ./public

USER nextjs

EXPOSE 3000

ENTRYPOINT ["dumb-init", "--"]
CMD ["node", "server.js"]
```

### 3. SSL Certificate Setup

#### Using Let's Encrypt

```bash
# Install Certbot
sudo apt install certbot python3-certbot-nginx

# Obtain SSL certificate
sudo certbot --nginx -d yourdomain.com -d api.yourdomain.com -d storage.yourdomain.com

# Test auto-renewal
sudo certbot renew --dry-run
```

### 4. Nginx Configuration

Create `/etc/nginx/sites-available/agricommerce`:

```nginx
# Frontend
server {
    listen 80;
    listen [::]:80;
    server_name yourdomain.com www.yourdomain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name yourdomain.com www.yourdomain.com;

    ssl_certificate /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers off;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }
}

# Backend API
server {
    listen 80;
    listen [::]:80;
    server_name api.yourdomain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name api.yourdomain.com;

    ssl_certificate /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers off;

    client_max_body_size 10M;

    location / {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
    }

    # WebSocket support
    location /socket.io/ {
        proxy_pass http://localhost:3001;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}

# MinIO Storage
server {
    listen 80;
    listen [::]:80;
    server_name storage.yourdomain.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    listen [::]:443 ssl http2;
    server_name storage.yourdomain.com;

    ssl_certificate /etc/letsencrypt/live/yourdomain.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/yourdomain.com/privkey.pem;
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-RSA-AES256-GCM-SHA512:DHE-RSA-AES256-GCM-SHA512:ECDHE-RSA-AES256-GCM-SHA384:DHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers off;

    client_max_body_size 100M;

    location / {
        proxy_pass http://localhost:9000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Enable the site:

```bash
sudo ln -s /etc/nginx/sites-available/agricommerce /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

### 5. Deploy Application

```bash
# Set production environment
export NODE_ENV=production

# Start services
docker-compose -f docker-compose.prod.yml up -d

# Run database migrations
docker-compose -f docker-compose.prod.yml exec backend npx prisma migrate deploy

# Seed database
docker-compose -f docker-compose.prod.yml exec backend npx prisma db seed

# Check services status
docker-compose -f docker-compose.prod.yml ps
```

### 6. Monitoring & Logging

#### Setup Log Rotation

Create `/etc/logrotate.d/agricommerce`:

```
/opt/agricommerce/logs/*.log {
    daily
    missingok
    rotate 52
    compress
    delaycompress
    notifempty
    create 644 root root
    postrotate
        docker-compose -f /opt/agricommerce/docker-compose.prod.yml restart backend frontend
    endscript
}
```

#### Health Check Script

Create `/opt/agricommerce/scripts/health-check.sh`:

```bash
#!/bin/bash

# Health check script for AgriCommerce

FRONTEND_URL="https://yourdomain.com"
BACKEND_URL="https://api.yourdomain.com/api/v1"

# Check frontend
if curl -f -s $FRONTEND_URL > /dev/null; then
    echo "✅ Frontend is healthy"
else
    echo "❌ Frontend is down"
    # Restart frontend
    docker-compose -f /opt/agricommerce/docker-compose.prod.yml restart frontend
fi

# Check backend
if curl -f -s $BACKEND_URL > /dev/null; then
    echo "✅ Backend is healthy"
else
    echo "❌ Backend is down"
    # Restart backend
    docker-compose -f /opt/agricommerce/docker-compose.prod.yml restart backend
fi

# Check database
if docker-compose -f /opt/agricommerce/docker-compose.prod.yml exec -T postgres pg_isready -U postgres > /dev/null; then
    echo "✅ Database is healthy"
else
    echo "❌ Database is down"
    # Restart database
    docker-compose -f /opt/agricommerce/docker-compose.prod.yml restart postgres
fi
```

Make it executable and add to crontab:

```bash
chmod +x /opt/agricommerce/scripts/health-check.sh

# Add to crontab (run every 5 minutes)
(crontab -l 2>/dev/null; echo "*/5 * * * * /opt/agricommerce/scripts/health-check.sh >> /var/log/agricommerce-health.log 2>&1") | crontab -
```

### 7. Backup Strategy

#### Database Backup Script

Create `/opt/agricommerce/scripts/backup-db.sh`:

```bash
#!/bin/bash

BACKUP_DIR="/opt/agricommerce/backup"
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="agricommerce_backup_$DATE.sql"

# Create backup directory
mkdir -p $BACKUP_DIR

# Create database backup
docker-compose -f /opt/agricommerce/docker-compose.prod.yml exec -T postgres pg_dump -U postgres agricommerce > $BACKUP_DIR/$BACKUP_FILE

# Compress backup
gzip $BACKUP_DIR/$BACKUP_FILE

# Remove backups older than 30 days
find $BACKUP_DIR -name "*.sql.gz" -mtime +30 -delete

echo "Database backup completed: $BACKUP_FILE.gz"
```

#### File Backup Script

Create `/opt/agricommerce/scripts/backup-files.sh`:

```bash
#!/bin/bash

BACKUP_DIR="/opt/agricommerce/backup"
DATE=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="agricommerce_files_backup_$DATE.tar.gz"

# Create backup directory
mkdir -p $BACKUP_DIR

# Backup MinIO data
docker run --rm -v agricommerce_minio_data:/data -v $BACKUP_DIR:/backup alpine tar czf /backup/$BACKUP_FILE -C /data .

# Remove file backups older than 7 days
find $BACKUP_DIR -name "*_files_backup_*.tar.gz" -mtime +7 -delete

echo "Files backup completed: $BACKUP_FILE"
```

Add to crontab:

```bash
# Database backup daily at 2 AM
(crontab -l 2>/dev/null; echo "0 2 * * * /opt/agricommerce/scripts/backup-db.sh >> /var/log/agricommerce-backup.log 2>&1") | crontab -

# Files backup weekly on Sunday at 3 AM
(crontab -l 2>/dev/null; echo "0 3 * * 0 /opt/agricommerce/scripts/backup-files.sh >> /var/log/agricommerce-backup.log 2>&1") | crontab -
```

## 🔄 CI/CD Pipeline

### GitHub Actions

Create `.github/workflows/deploy.yml`:

```yaml
name: Deploy to Production

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    
    steps:
    - uses: actions/checkout@v3
    
    - name: Setup Node.js
      uses: actions/setup-node@v3
      with:
        node-version: '18'
        cache: 'npm'
        cache-dependency-path: |
          backend/package-lock.json
          frontend/package-lock.json
    
    - name: Install backend dependencies
      run: |
        cd backend
        npm ci
    
    - name: Install frontend dependencies
      run: |
        cd frontend
        npm ci
    
    - name: Run tests
      run: |
        cd backend
        npm run test
    
    - name: Build applications
      run: |
        cd backend
        npm run build
        cd ../frontend
        npm run build
    
    - name: Deploy to server
      uses: appleboy/ssh-action@v0.1.5
      with:
        host: ${{ secrets.HOST }}
        username: ${{ secrets.USERNAME }}
        key: ${{ secrets.SSH_KEY }}
        script: |
          cd /opt/agricommerce
          git pull origin main
          docker-compose -f docker-compose.prod.yml build
          docker-compose -f docker-compose.prod.yml up -d
          docker-compose -f docker-compose.prod.yml exec -T backend npx prisma migrate deploy
```

## 📊 Performance Optimization

### Database Optimization

```sql
-- Add indexes for better performance
CREATE INDEX CONCURRENTLY idx_products_category_status ON products(category_id, status);
CREATE INDEX CONCURRENTLY idx_auctions_status_end_time ON auctions(status, end_time);
CREATE INDEX CONCURRENTLY idx_orders_buyer_status ON orders(buyer_id, status);
CREATE INDEX CONCURRENTLY idx_messages_chat_created ON messages(chat_id, created_at);
```

### Redis Configuration

```bash
# Optimize Redis for production
echo 'vm.overcommit_memory = 1' >> /etc/sysctl.conf
echo 'net.core.somaxconn = 65535' >> /etc/sysctl.conf
sysctl -p
```

### Nginx Optimization

Add to nginx configuration:

```nginx
# Enable gzip compression
gzip on;
gzip_vary on;
gzip_min_length 1024;
gzip_types text/plain text/css text/xml text/javascript application/javascript application/xml+rss application/json;

# Enable caching
location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
    expires 1y;
    add_header Cache-Control "public, immutable";
}

# Security headers
add_header X-Frame-Options "SAMEORIGIN" always;
add_header X-XSS-Protection "1; mode=block" always;
add_header X-Content-Type-Options "nosniff" always;
add_header Referrer-Policy "no-referrer-when-downgrade" always;
add_header Content-Security-Policy "default-src 'self' http: https: data: blob: 'unsafe-inline'" always;
```

## 🔐 Security Hardening

### Server Security

```bash
# Disable root login
sudo sed -i 's/PermitRootLogin yes/PermitRootLogin no/' /etc/ssh/sshd_config

# Change SSH port
sudo sed -i 's/#Port 22/Port 2222/' /etc/ssh/sshd_config

# Restart SSH
sudo systemctl restart ssh

# Install fail2ban
sudo apt install fail2ban

# Configure fail2ban
sudo cp /etc/fail2ban/jail.conf /etc/fail2ban/jail.local
sudo systemctl enable fail2ban
sudo systemctl start fail2ban
```

### Application Security

```bash
# Set secure file permissions
sudo chown -R www-data:www-data /opt/agricommerce
sudo chmod -R 755 /opt/agricommerce
sudo chmod -R 644 /opt/agricommerce/.env*
```

## 📱 Mobile App Deployment

### PWA Configuration

The frontend is already configured as PWA. To enhance mobile experience:

1. **App Store Deployment**: Use Capacitor to build native apps
2. **Push Notifications**: Implement Firebase Cloud Messaging
3. **Offline Support**: Enhance service worker for offline functionality

## 🌍 Multi-region Deployment

### Load Balancer Setup

For high availability, deploy across multiple regions:

1. **Primary Region**: Main application servers
2. **Secondary Region**: Backup servers with database replication
3. **CDN**: Use CloudFlare or AWS CloudFront for static assets
4. **Database**: Setup PostgreSQL streaming replication

## 📈 Scaling

### Horizontal Scaling

```yaml
# docker-compose.scale.yml
version: '3.8'

services:
  backend:
    deploy:
      replicas: 3
  
  frontend:
    deploy:
      replicas: 2
```

### Load Balancing

```nginx
upstream backend {
    server localhost:3001;
    server localhost:3002;
    server localhost:3003;
}

upstream frontend {
    server localhost:3000;
    server localhost:3004;
}
```

## 🆘 Troubleshooting

### Common Production Issues

1. **High Memory Usage**: Monitor with `htop` and adjust container limits
2. **Database Locks**: Monitor slow queries and optimize indexes
3. **SSL Certificate Renewal**: Ensure certbot cron job is working
4. **File Upload Issues**: Check MinIO permissions and disk space

### Emergency Procedures

1. **Service Down**: Use health check script to restart services
2. **Database Corruption**: Restore from latest backup
3. **High Traffic**: Enable rate limiting and scale horizontally
4. **Security Breach**: Immediately rotate all secrets and keys

## 📞 Support

For production deployment support:
- **Documentation**: Check all docs in `/docs` folder
- **Monitoring**: Setup monitoring dashboard
- **Alerts**: Configure email/SMS alerts for critical issues
- **Support Team**: Contact DevOps team for assistance

