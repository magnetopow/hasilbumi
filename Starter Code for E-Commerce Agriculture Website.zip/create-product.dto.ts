import { IsString, IsNumber, IsArray, IsBoolean, IsOptional, Min } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class CreateProductDto {
  @ApiProperty({ example: 'Beras Premium Organik' })
  @IsString()
  name: string;

  @ApiProperty({ example: 'Beras organik berkualitas tinggi dari sawah terpilih' })
  @IsString()
  description: string;

  @ApiProperty({ example: 'category-id-here' })
  @IsString()
  categoryId: string;

  @ApiProperty({ example: 15000 })
  @IsNumber()
  @Min(0)
  price: number;

  @ApiProperty({ example: 100 })
  @IsNumber()
  @Min(0)
  stock: number;

  @ApiProperty({ example: 'kg' })
  @IsString()
  unit: string;

  @ApiProperty({ example: 5 })
  @IsNumber()
  @Min(1)
  minOrder: number;

  @ApiProperty({ example: ['/images/product1.jpg', '/images/product2.jpg'] })
  @IsArray()
  @IsString({ each: true })
  images: string[];

  @ApiProperty({ example: ['organik', 'premium', 'bebas-pestisida'] })
  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  tags?: string[];

  @ApiProperty({ example: true })
  @IsOptional()
  @IsBoolean()
  isAuctionable?: boolean;
}

